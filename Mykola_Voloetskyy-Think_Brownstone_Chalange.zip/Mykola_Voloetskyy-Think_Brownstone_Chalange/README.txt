0)Pull request from github storage.

1) Create structure. index.html then directives: css --> style.css
                                             scripts --> index.js, angular.min.js
                                                 img --> all images for project
                                             storage --> store .json file

2) Create Angular App in index.js module  --> railFares
                               controller --> railFaresCtrl

3) In controller request fares.json by $http module, then read data and create
   populate(bind) it to index.html with $scope.

4) HTML markup. Then read inputs by ng-model and bg-change to call function and update price
    in live time. Also, Angular filter Currency to show proper format of total price.

5) CSS--> custom inputs: select boxes and radio button with gradient blue dot.
   Help (explanation) texts below the inputs with following labels: "Where are you riding? and Where will you
   purchase the fare?"
