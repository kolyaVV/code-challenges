/**
 * Created by kolyavolosetskyy on 7/18/16.
 */
'use strict';

angular.module('railFares', [])

    .controller('railFaresCtrl', ['$scope', '$http', function ($scope, $http) {
        //get data from file 
        $http.get('./storage/fares.json')

            //connection respond with success
            .success(function (data, status) {
                console.log("Success getting data ");

                //Declare variables and $scope variables
                var info = data.info;
                $scope.zones = data.zones;
                $scope.zoneNum = 1;
                $scope.type = 'weekday';
                $scope.purchase = 'advance_purchase';
                $scope.numRides = 1;
                $scope.ridesTickets = 'rides';
                
                //Live time update of price
                $scope.reload = function () {
                    var zoneN = $scope.zoneNum;
                    var fares = data.zones[zoneN - 1].fares;

                    //Check user inputs and assign needed help info accordingly
                    //If Anytime type of ride checked then change Label help text 
                    // and help info
                    if ($scope.type == 'anytime') {
                        var num = $scope.numRides;

                        $scope.numRidesTckt = 'TOTAL RIDES: ' + num * 10;
                        $scope.infoType = info.anytime;
                        $scope.purchase = 'advance_purchase';
                        $scope.rides_tickets = '"10 rides anytime tickets"';
                        
                    } else {
                        $scope.numRidesTckt = '';
                        $scope.rides_tickets = 'rides';
                    }

                    if ($scope.type == 'weekday') {
                        $scope.infoType = info.weekday;
                    }

                    if ($scope.type == 'evening_weekend') {
                        $scope.infoType = info.evening_weekend;
                    }

                    if ($scope.purchase == 'advance_purchase') {
                        $scope.infoPurchase = info.advance_purchase;
                    }

                    if ($scope.purchase == 'onboard_purchase') {
                        $scope.infoPurchase = info.onboard_purchase;
                    }

                    //Loop in fares to find what price to show according to what user want
                    for (var i = 0; i < fares.length; i++) {
                        if ($scope.type == fares[i].type &&
                            $scope.purchase == fares[i].purchase) {
                            console.log(fares[i].price);
                            if ($scope.type == 'anytime') {
                                $scope.priceToPay = fares[i].price * num;

                            } else {
                                $scope.priceToPay = fares[i].price * $scope.numRides;
                            }
                        }
                    }
                };
                $scope.reload();
            })
            .error(function (data, status) {
                console.log("Error getting data " + data + " " + status)
            });
    }]);


